#!/bin/bash
# Script d'installation automatique - Infrastructure AAA SecuriAuth
# Version 1.0 - 2025

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║       Installation Infrastructure AAA SecuriAuth Sénégal      ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Fonction d'affichage
print_step() {
    echo -e "${BLUE}[ÉTAPE]${NC} $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Vérifier que nous sommes dans le bon répertoire
if [ ! -f "docker-compose.yml" ]; then
    print_error "Erreur: docker-compose.yml introuvable!"
    print_warning "Veuillez exécuter ce script depuis le répertoire securiauth-aaa/"
    exit 1
fi

print_success "Répertoire de projet détecté: $(pwd)"
echo ""

# Étape 1: Vérifier Docker
print_step "1/8 Vérification de Docker..."
if ! command -v docker &> /dev/null; then
    print_warning "Docker n'est pas installé. Installation en cours..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    rm get-docker.sh
    print_success "Docker installé!"
    print_warning "IMPORTANT: Vous devez vous déconnecter/reconnecter pour utiliser Docker sans sudo"
    print_warning "Ou exécutez: newgrp docker"
else
    print_success "Docker $(docker --version | cut -d' ' -f3) détecté"
fi
echo ""

# Étape 2: Vérifier ldap-utils
print_step "2/8 Vérification des outils LDAP..."
if ! command -v ldapsearch &> /dev/null; then
    print_warning "ldap-utils non installé. Installation en cours..."
    sudo apt-get update -qq
    sudo apt-get install -y ldap-utils
    print_success "ldap-utils installé!"
else
    print_success "ldap-utils installé"
fi
echo ""

# Étape 3: Vérifier/Générer PKI
print_step "3/8 Vérification de la PKI..."
if [ ! -f "pki/ca/ca-cert.pem" ]; then
    print_warning "PKI non trouvée. Génération en cours..."
    if [ -f "scripts/generate-pki.sh" ]; then
        chmod +x scripts/generate-pki.sh
        ./scripts/generate-pki.sh
        print_success "PKI générée!"
    else
        print_error "Script generate-pki.sh introuvable!"
        exit 1
    fi
else
    print_success "PKI déjà générée"
fi
echo ""

# Étape 4: Créer répertoires nécessaires
print_step "4/8 Création des répertoires de données..."
sudo mkdir -p openldap/data openldap/config mysql/data
sudo chmod -R 755 openldap mysql
print_success "Répertoires créés"
echo ""

# Étape 5: Démarrer services de base
print_step "5/8 Démarrage des services de base (LDAP, MySQL, phpLDAPadmin)..."
sudo docker compose up -d openldap mysql-radius phpldapadmin
echo ""
print_success "Services de base démarrés"
echo ""

# Attendre que les services soient prêts
print_step "Attente de l'initialisation des services (30 secondes)..."
for i in {30..1}; do
    printf "\r  ⏳ ${i}s restantes...  "
    sleep 1
done
echo ""
print_success "Services initialisés"
echo ""

# Étape 6: Charger données LDAP
print_step "6/8 Chargement des données LDAP..."

# Créer les OUs
print_warning "  → Création des unités organisationnelles..."
cat > /tmp/securiauth-ous.ldif << 'EOFLDIF'
dn: ou=Utilisateurs,dc=securiauth,dc=com
objectClass: organizationalUnit
ou: Utilisateurs

dn: ou=Groupes,dc=securiauth,dc=com
objectClass: organizationalUnit
ou: Groupes

dn: ou=Equipements,dc=securiauth,dc=com
objectClass: organizationalUnit
ou: Equipements
EOFLDIF

ldapadd -x -H ldap://localhost:389 \
    -D "cn=admin,dc=securiauth,dc=com" \
    -w "AdminSecur1Auth2025!" \
    -f /tmp/securiauth-ous.ldif 2>/dev/null || true

# Charger utilisateurs
if [ -f "openldap/ldif/03-utilisateurs.ldif" ]; then
    print_warning "  → Import des utilisateurs..."
    ldapadd -x -H ldap://localhost:389 \
        -D "cn=admin,dc=securiauth,dc=com" \
        -w "AdminSecur1Auth2025!" \
        -f openldap/ldif/03-utilisateurs.ldif 2>/dev/null || true
    print_success "  Utilisateurs importés"
fi

# Charger groupes
if [ -f "openldap/ldif/02-groupes.ldif" ]; then
    print_warning "  → Import des groupes..."
    ldapadd -x -H ldap://localhost:389 \
        -D "cn=admin,dc=securiauth,dc=com" \
        -w "AdminSecur1Auth2025!" \
        -f openldap/ldif/02-groupes.ldif 2>/dev/null || true
    print_success "  Groupes importés"
fi

rm /tmp/securiauth-ous.ldif
print_success "Données LDAP chargées"
echo ""

# Étape 7: Construire et démarrer RADIUS/TACACS+
print_step "7/8 Construction des images RADIUS et TACACS+..."
sudo docker compose build freeradius1 freeradius2 tacacsplus1 tacacsplus2
print_success "Images construites"
echo ""

print_step "Démarrage des services RADIUS et TACACS+..."
sudo docker compose up -d freeradius1 freeradius2 tacacsplus1 tacacsplus2
print_success "Services AAA démarrés"
echo ""

# Étape 8: Vérification finale
print_step "8/8 Vérification de l'installation..."
sleep 5

echo ""
echo "État des conteneurs:"
sudo docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | grep securiauth || true

echo ""
echo "Test de connectivité LDAP:"
if ldapsearch -x -H ldap://localhost:389 \
    -D "cn=admin,dc=securiauth,dc=com" \
    -w "AdminSecur1Auth2025!" \
    -b "dc=securiauth,dc=com" -s base dn &>/dev/null; then
    print_success "LDAP opérationnel"
else
    print_error "LDAP non accessible"
fi

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                                                                ║"
echo "║              ✅  INSTALLATION TERMINÉE AVEC SUCCÈS !            ║"
echo "║                                                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "📍 Services déployés:"
echo "   • OpenLDAP:      ldap://localhost:389"
echo "   • phpLDAPadmin:  http://localhost:8080"
echo "   • MySQL:         localhost:3306"
echo "   • RADIUS 1:      localhost:1812-1813"
echo "   • RADIUS 2:      localhost:1912-1913"
echo "   • TACACS+ 1:     localhost:49"
echo "   • TACACS+ 2:     localhost:50"
echo ""
echo "🔑 Identifiants par défaut:"
echo "   • LDAP Admin: cn=admin,dc=securiauth,dc=com / AdminSecur1Auth2025!"
echo "   • phpLDAPadmin: http://localhost:8080 (mêmes identifiants)"
echo ""
echo "📚 Documentation:"
echo "   • README.md - Guide de démarrage"
echo "   • docs/GUIDE-COMPLET-FR.md - Documentation complète"
echo "   • DEPLOYMENT-STATUS.md - État du déploiement"
echo ""
echo "⚠️  IMPORTANT: Changez tous les mots de passe avant la production!"
echo ""
echo "🇸🇳 SecuriAuth Sénégal - Infrastructure AAA 2025"
echo ""
