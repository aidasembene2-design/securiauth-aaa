#!/bin/bash
# Script de génération PKI pour SecuriAuth Sénégal
# Infrastructure AAA - 2025

set -e

PKI_DIR="$HOME/securiauth-aaa/pki"
CA_DIR="$PKI_DIR/ca"
SERVER_DIR="$PKI_DIR/server"
CLIENT_DIR="$PKI_DIR/client"

echo "=========================================="
echo "  PKI SecuriAuth - Génération Certificats"
echo "=========================================="

# Nettoyage
rm -rf "$PKI_DIR"/*
mkdir -p "$CA_DIR" "$SERVER_DIR" "$CLIENT_DIR"

# ==================== CA ROOT ====================
echo "[1/4] Génération de l'Autorité de Certification (CA Root)..."
cd "$CA_DIR"

# Clé privée CA
openssl genrsa -out ca-key.pem 4096

# Certificat CA (valide 10 ans)
openssl req -new -x509 -days 3650 -key ca-key.pem -out ca-cert.pem \
  -subj "/C=SN/ST=Dakar/L=Dakar/O=SecuriAuth Sénégal/OU=PKI/CN=SecuriAuth Root CA/emailAddress=pki@securiauth.com"

echo "✓ CA Root générée"

# ==================== CERTIFICATS SERVEURS RADIUS ====================
echo "[2/4] Génération certificats serveurs RADIUS..."
cd "$SERVER_DIR"

# Serveur RADIUS 1
openssl genrsa -out radius1-key.pem 2048
openssl req -new -key radius1-key.pem -out radius1-csr.pem \
  -subj "/C=SN/ST=Dakar/L=Dakar/O=SecuriAuth Sénégal/OU=RADIUS/CN=radius1.securiauth.com/emailAddress=radius@securiauth.com"
openssl x509 -req -in radius1-csr.pem -CA "$CA_DIR/ca-cert.pem" -CAkey "$CA_DIR/ca-key.pem" \
  -CAcreateserial -out radius1-cert.pem -days 730

# Serveur RADIUS 2
openssl genrsa -out radius2-key.pem 2048
openssl req -new -key radius2-key.pem -out radius2-csr.pem \
  -subj "/C=SN/ST=Dakar/L=Dakar/O=SecuriAuth Sénégal/OU=RADIUS/CN=radius2.securiauth.com/emailAddress=radius@securiauth.com"
openssl x509 -req -in radius2-csr.pem -CA "$CA_DIR/ca-cert.pem" -CAkey "$CA_DIR/ca-key.pem" \
  -CAcreateserial -out radius2-cert.pem -days 730

# Paramètres DH pour EAP-TLS
openssl dhparam -out dh2048.pem 2048

echo "✓ Certificats serveurs RADIUS générés"

# ==================== CERTIFICATS CLIENTS ====================
echo "[3/4] Génération certificats clients (utilisateurs)..."
cd "$CLIENT_DIR"

# Fonction pour générer un certificat client
generate_client_cert() {
    local username=$1
    local fullname=$2
    echo "  → Certificat pour $fullname"
    
    openssl genrsa -out "${username}-key.pem" 2048
    openssl req -new -key "${username}-key.pem" -out "${username}-csr.pem" \
      -subj "/C=SN/ST=Dakar/L=Dakar/O=SecuriAuth Sénégal/OU=Utilisateurs/CN=${fullname}/emailAddress=${username}@securiauth.com"
    openssl x509 -req -in "${username}-csr.pem" -CA "$CA_DIR/ca-cert.pem" -CAkey "$CA_DIR/ca-key.pem" \
      -CAcreateserial -out "${username}-cert.pem" -days 365
    
    # Créer bundle PKCS#12 (pour import facile sur clients)
    openssl pkcs12 -export -out "${username}.p12" \
      -inkey "${username}-key.pem" -in "${username}-cert.pem" -certfile "$CA_DIR/ca-cert.pem" \
      -passout pass:SecuriAuth2025
}

generate_client_cert "dieyna.diop" "Dieyna Diop"
generate_client_cert "maman.seck" "Maman Seck"
generate_client_cert "aida.fall" "Aida Fall"
generate_client_cert "ousmane.diallo" "Ousmane Diallo"
generate_client_cert "fatou.sarr" "Fatou Sarr"
generate_client_cert "moussa.ndiaye" "Moussa Ndiaye"

echo "✓ Certificats clients générés"

# ==================== RÉSUMÉ ====================
echo "[4/4] Configuration des permissions..."
cd "$PKI_DIR"
chmod 600 ca/ca-key.pem
chmod 644 ca/ca-cert.pem
chmod 600 server/*-key.pem
chmod 644 server/*-cert.pem
chmod 600 client/*-key.pem
chmod 644 client/*-cert.pem
chmod 644 client/*.p12

echo ""
echo "=========================================="
echo "  ✓ PKI Générée avec succès!"
echo "=========================================="
echo ""
echo "Fichiers générés:"
echo "  CA Root:       $CA_DIR/ca-cert.pem"
echo "  RADIUS 1:      $SERVER_DIR/radius1-cert.pem"
echo "  RADIUS 2:      $SERVER_DIR/radius2-cert.pem"
echo "  Clients:       $CLIENT_DIR/*.p12 (password: SecuriAuth2025)"
echo ""
echo "Pour distribuer aux clients:"
echo "  - CA: $CA_DIR/ca-cert.pem"
echo "  - Client bundles: $CLIENT_DIR/<username>.p12"
echo ""
