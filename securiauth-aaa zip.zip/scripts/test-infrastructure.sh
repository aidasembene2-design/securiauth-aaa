#!/bin/bash
# Script de tests complets - Infrastructure SecuriAuth
# 2025

set -e

YELLOW='\033[1;33m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo "=========================================="
echo "  Tests Infrastructure SecuriAuth"
echo "=========================================="
echo ""

# Fonction de test
test_step() {
    echo -e "${YELLOW}[TEST]${NC} $1"
}

test_ok() {
    echo -e "${GREEN}  ✓ $1${NC}"
}

test_fail() {
    echo -e "${RED}  ✗ $1${NC}"
    exit 1
}

# Test 1: Vérifier conteneurs Docker
test_step "1. Vérification conteneurs Docker"
if sudo docker ps | grep -q "securiauth-ldap"; then
    test_ok "OpenLDAP démarré"
else
    test_fail "OpenLDAP non démarré"
fi

if sudo docker ps | grep -q "securiauth-mysql"; then
    test_ok "MySQL démarré"
else
    test_fail "MySQL non démarré"
fi

if sudo docker ps | grep -q "securiauth-ldap-admin"; then
    test_ok "phpLDAPadmin démarré"
else
    test_fail "phpLDAPadmin non démarré"
fi

# Test 2: Connectivité LDAP
test_step "2. Test connexion LDAP"
if ldapsearch -x -H ldap://localhost:389 \
    -D "cn=admin,dc=securiauth,dc=com" \
    -w "AdminSecur1Auth2025!" \
    -b "dc=securiauth,dc=com" \
    -s base "(objectClass=*)" dn &>/dev/null; then
    test_ok "Connexion LDAP réussie"
else
    test_fail "Échec connexion LDAP"
fi

# Test 3: Vérifier utilisateurs LDAP
test_step "3. Vérification utilisateurs LDAP"
USERS=("dieyna.diop" "maman.seck" "aida.fall")
for user in "${USERS[@]}"; do
    if ldapsearch -x -H ldap://localhost:389 \
        -D "cn=admin,dc=securiauth,dc=com" \
        -w "AdminSecur1Auth2025!" \
        -b "dc=securiauth,dc=com" \
        "(uid=$user)" dn 2>/dev/null | grep -q "dn:"; then
        test_ok "Utilisateur $user existe"
    else
        test_fail "Utilisateur $user manquant"
    fi
done

# Test 4: Vérifier groupes LDAP
test_step "4. Vérification groupes LDAP"
GROUPS=("Administrateurs" "Techniciens" "Support")
for group in "${GROUPS[@]}"; do
    if ldapsearch -x -H ldap://localhost:389 \
        -D "cn=admin,dc=securiauth,dc=com" \
        -w "AdminSecur1Auth2025!" \
        -b "ou=Groupes,dc=securiauth,dc=com" \
        "(cn=$group)" dn 2>/dev/null | grep -q "dn:"; then
        test_ok "Groupe $group existe"
    else
        test_fail "Groupe $group manquant"
    fi
done

# Test 5: Vérifier appartenance groupe
test_step "5. Test appartenance aux groupes"
if ldapsearch -x -H ldap://localhost:389 \
    -D "cn=admin,dc=securiauth,dc=com" \
    -w "AdminSecur1Auth2025!" \
    -b "ou=Groupes,dc=securiauth,dc=com" \
    "(cn=Administrateurs)" member 2>/dev/null | grep -q "Dieyna"; then
    test_ok "Dieyna membre du groupe Administrateurs"
else
    test_fail "Appartenance groupe incorrecte"
fi

# Test 6: Connectivité MySQL
test_step "6. Test connexion MySQL"
if sudo docker exec securiauth-mysql mysql \
    -uradiususer -pRadiusDB2025! \
    -e "SELECT 1;" radius &>/dev/null; then
    test_ok "Connexion MySQL réussie"
else
    test_fail "Échec connexion MySQL"
fi

# Test 7: Tables RADIUS
test_step "7. Vérification tables RADIUS"
TABLES=("radacct" "nas" "radgroupreply")
for table in "${TABLES[@]}"; do
    if sudo docker exec securiauth-mysql mysql \
        -uradiususer -pRadiusDB2025! \
        -e "DESCRIBE $table;" radius &>/dev/null; then
        test_ok "Table $table existe"
    else
        test_fail "Table $table manquante"
    fi
done

# Test 8: Certificats PKI
test_step "8. Vérification certificats PKI"
if [ -f "$HOME/securiauth-aaa/pki/ca/ca-cert.pem" ]; then
    test_ok "Certificat CA existe"
else
    test_fail "Certificat CA manquant"
fi

if [ -f "$HOME/securiauth-aaa/pki/server/radius1-cert.pem" ]; then
    test_ok "Certificat RADIUS 1 existe"
else
    test_fail "Certificat RADIUS 1 manquant"
fi

if [ -f "$HOME/securiauth-aaa/pki/client/dieyna.diop.p12" ]; then
    test_ok "Certificat client Dieyna existe"
else
    test_fail "Certificat client Dieyna manquant"
fi

# Test 9: Validité certificats
test_step "9. Test validité certificats"
if openssl x509 -in "$HOME/securiauth-aaa/pki/ca/ca-cert.pem" \
    -noout -checkend 0 &>/dev/null; then
    test_ok "Certificat CA valide"
else
    test_fail "Certificat CA expiré"
fi

if openssl x509 -in "$HOME/securiauth-aaa/pki/server/radius1-cert.pem" \
    -noout -checkend 0 &>/dev/null; then
    test_ok "Certificat RADIUS valide"
else
    test_fail "Certificat RADIUS expiré"
fi

# Test 10: Ports réseau
test_step "10. Test ports réseau ouverts"
PORTS=("389" "8080" "3306")
for port in "${PORTS[@]}"; do
    if nc -z localhost $port 2>/dev/null; then
        test_ok "Port $port ouvert"
    else
        test_fail "Port $port fermé"
    fi
done

# Test 11: Logs conteneurs
test_step "11. Vérification logs (erreurs critiques)"
if sudo docker logs securiauth-ldap 2>&1 | grep -qi "fatal\|error" | head -5; then
    echo "  ⚠ Erreurs détectées dans logs LDAP (vérifier manuellement)"
else
    test_ok "Pas d'erreur critique dans logs LDAP"
fi

# Test 12: phpLDAPadmin accessible
test_step "12. Test accessibilité phpLDAPadmin"
if curl -s http://localhost:8080 | grep -q "phpLDAPadmin" 2>/dev/null; then
    test_ok "phpLDAPadmin accessible"
else
    test_fail "phpLDAPadmin inaccessible"
fi

echo ""
echo "=========================================="
echo -e "${GREEN}  ✓ Tous les tests réussis!${NC}"
echo "=========================================="
echo ""
echo "Résumé de l'infrastructure:"
echo "  - OpenLDAP: ldap://localhost:389"
echo "  - phpLDAPadmin: http://localhost:8080"
echo "  - MySQL: localhost:3306"
echo "  - Utilisateurs: 6 (dieyna.diop, maman.seck, aida.fall, ...)"
echo "  - Groupes: 6 (Administrateurs, Techniciens, Support, ...)"
echo "  - Certificats PKI: ✓"
echo ""
echo "Prochaines étapes:"
echo "  1. Construire images RADIUS/TACACS+:"
echo "     sudo docker compose build freeradius1 tacacsplus1"
echo "  2. Démarrer services AAA:"
echo "     sudo docker compose up -d freeradius1 freeradius2 tacacsplus1 tacacsplus2"
echo "  3. Tester authentification RADIUS:"
echo "     radtest dieyna.diop <password> localhost:1812 0 testing123"
echo ""
