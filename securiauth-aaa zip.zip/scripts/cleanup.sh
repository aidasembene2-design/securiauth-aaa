#!/bin/bash
# Script de nettoyage - Infrastructure AAA SecuriAuth

echo "Nettoyage de l'infrastructure SecuriAuth..."

# Arrêter tous les conteneurs
echo "  → Arrêt des conteneurs..."
sudo docker compose down

# Supprimer volumes Docker (optionnel)
read -p "Supprimer aussi les volumes Docker (données LDAP/MySQL)? (o/N) " -n 1 -r
echo
if [[ $REPLY =~ ^[Oo]$ ]]; then
    echo "  → Suppression des volumes..."
    sudo docker compose down -v
fi

# Nettoyer données locales
read -p "Supprimer les données locales (openldap/data, mysql/data)? (o/N) " -n 1 -r
echo
if [[ $REPLY =~ ^[Oo]$ ]]; then
    echo "  → Suppression des données locales..."
    sudo rm -rf openldap/data/* openldap/config/cn=config/* mysql/data/*
fi

echo "✓ Nettoyage terminé!"
