# SecuriAuth - Infrastructure AAA Sénégal 🇸🇳

Infrastructure complète Authentication, Authorization & Accounting pour organisations sénégalaises.

## 🚀 Démarrage Rapide

```bash
# 1. Générer certificats PKI
./scripts/generate-pki.sh

# 2. Démarrer l'infrastructure
sudo docker compose up -d

# 3. Charger données LDAP
ldapadd -x -H ldap://localhost:389 -D "cn=admin,dc=securiauth,dc=com" \
  -w "AdminSecur1Auth2025!" -f openldap/ldif/03-utilisateurs.ldif
ldapadd -x -H ldap://localhost:389 -D "cn=admin,dc=securiauth,dc=com" \
  -w "AdminSecur1Auth2025!" -f openldap/ldif/02-groupes.ldif

# 4. Tester
ldapsearch -x -H ldap://localhost:389 -D "cn=admin,dc=securiauth,dc=com" \
  -w "AdminSecur1Auth2025!" -b "dc=securiauth,dc=com" "(uid=dieyna.diop)"
```

## 📦 Composants

- **OpenLDAP** (port 389): Annuaire d'identités
- **phpLDAPadmin** (port 8080): Interface web LDAP  
- **FreeRADIUS** (ports 1812/1813, 1912/1913): Serveurs AAA pour VPN/Wi-Fi (x2)
- **TACACS+** (ports 49, 50): Serveurs AAA pour équipements réseau (x2)
- **MySQL** (port 3306): Base de données accounting
- **PKI**: Autorité de certification interne

## 👥 Utilisateurs Prédéfinis

| Utilisateur    | Groupe           | Rôle                          | Ville       |
|----------------|------------------|-------------------------------|-------------|
| dieyna.diop    | Administrateurs  | Admin principal               | Dakar       |
| maman.seck     | Techniciens      | Technicien réseau senior      | Dakar       |
| aida.fall      | Support          | Support technique             | Thiès       |
| ousmane.diallo | Techniciens      | Technicien réseau             | Saint-Louis |
| fatou.sarr     | Support          | Support junior                | Dakar       |
| moussa.ndiaye  | Invités          | Consultant externe            | Dakar       |

## 🔑 Identifiants par défaut

| Service           | Utilisateur | Mot de passe           |
|-------------------|-------------|------------------------|
| LDAP Admin        | admin       | AdminSecur1Auth2025!   |
| MySQL Root        | root        | RootMySQL2025!         |
| MySQL RADIUS      | radiususer  | RadiusDB2025!          |
| TACACS+ Key       | -           | TacacsSecuriAuth2025!  |
| Certificats P12   | -           | SecuriAuth2025         |

⚠️ **À CHANGER EN PRODUCTION!**

## 🌐 Accès Web

- phpLDAPadmin: http://localhost:8080
  - Login: `cn=admin,dc=securiauth,dc=com`
  - Password: `AdminSecur1Auth2025!`

## 📖 Documentation

Voir `docs/GUIDE-COMPLET-FR.md` pour la documentation complète en français.

## 🧪 Tests

```bash
# Test LDAP
ldapsearch -x -H ldap://localhost:389 -D "cn=admin,dc=securiauth,dc=com" \
  -w "AdminSecur1Auth2025!" -b "dc=securiauth,dc=com"

# Vérifier services
sudo docker ps
sudo docker compose logs -f
```

## 🏗️ Architecture

```
┌─────────────────────────────────────────────┐
│         Infrastructure SecuriAuth            │
├─────────────────────────────────────────────┤
│                                             │
│  OpenLDAP (:389) ◄── phpLDAPadmin (:8080)  │
│      │                                      │
│      ├──► FreeRADIUS 1 (:1812/1813) ─┐     │
│      ├──► FreeRADIUS 2 (:1912/1913) ─┤     │
│      │                                │     │
│      ├──► TACACS+ 1 (:49)            MySQL │
│      └──► TACACS+ 2 (:50)            (:3306)│
│                                             │
└─────────────────────────────────────────────┘
```

## 📞 Support

- Infrastructure: dieyna.diop@securiauth.com (+221 77 123 45 67)
- Technique: maman.seck@securiauth.com (+221 76 234 56 78)
- Helpdesk: support@securiauth.com

---

**SecuriAuth Sénégal - 2025**
