# 📦 Package Infrastructure AAA SecuriAuth Sénégal

**Version:** 1.0  
**Date:** 2025-11-05  
**Organisation:** SecuriAuth Sénégal  
**Domaine:** securiauth.com

---

## 🎯 Contenu du Package

Ce package contient une infrastructure AAA (Authentication, Authorization, Accounting) complète et dockerisée pour organisations sénégalaises.

### Composants inclus

- **OpenLDAP** : Annuaire d'identités centralisé
- **FreeRADIUS** : Serveur AAA pour VPN/Wi-Fi (2 instances redondantes)
- **TACACS+** : Serveur AAA pour équipements réseau (2 instances)
- **MySQL** : Base de données accounting
- **phpLDAPadmin** : Interface web de gestion LDAP
- **PKI** : Infrastructure à clés publiques (CA + certificats)

### Données préconfigurées

- **6 utilisateurs** sénégalais (Dieyna, Maman, Aida, Ousmane, Fatou, Moussa)
- **6 groupes** avec mappings VLANs et privilèges
- **Villes** : Dakar, Thiès, Saint-Louis
- **Mapping VLANs** : Administrateurs=10, Techniciens=20, Support=30, Invités=99

---

## 🚀 Installation Rapide

### Prérequis

- **OS** : Ubuntu 20.04+ / Debian 11+ / Linux compatible
- **RAM** : 4 GB minimum (8 GB recommandé)
- **Disque** : 20 GB libres minimum
- **Accès** : Droits sudo

### Étapes d'installation

```bash
# 1. Extraire le package
unzip securiauth-aaa-v1.0.zip
cd securiauth-aaa

# 2. Rendre le script exécutable (si nécessaire)
chmod +x INSTALL.sh

# 3. Lancer l'installation automatique
./INSTALL.sh
```

Le script va automatiquement :
- ✅ Vérifier/installer Docker
- ✅ Générer la PKI si nécessaire
- ✅ Démarrer tous les services
- ✅ Charger les données LDAP
- ✅ Vérifier l'installation

**Durée estimée :** 5-10 minutes

---

## 📋 Installation Manuelle (Alternative)

Si vous préférez contrôler chaque étape :

```bash
# 1. Installer Docker (si nécessaire)
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER
newgrp docker

# 2. Installer ldap-utils
sudo apt-get update
sudo apt-get install -y ldap-utils

# 3. Générer la PKI
./scripts/generate-pki.sh

# 4. Démarrer services de base
docker compose up -d openldap mysql-radius phpldapadmin

# 5. Attendre 30 secondes, puis charger données LDAP
sleep 30
ldapadd -x -H ldap://localhost:389 \
  -D "cn=admin,dc=securiauth,dc=com" \
  -w "AdminSecur1Auth2025!" \
  -f openldap/ldif/03-utilisateurs.ldif
ldapadd -x -H ldap://localhost:389 \
  -D "cn=admin,dc=securiauth,dc=com" \
  -w "AdminSecur1Auth2025!" \
  -f openldap/ldif/02-groupes.ldif

# 6. Construire et démarrer RADIUS/TACACS+
docker compose build freeradius1 freeradius2 tacacsplus1 tacacsplus2
docker compose up -d freeradius1 freeradius2 tacacsplus1 tacacsplus2

# 7. Vérifier
docker ps
```

---

## 🔑 Accès aux Services

### OpenLDAP
```bash
# Ligne de commande
ldapsearch -x -H ldap://localhost:389 \
  -D "cn=admin,dc=securiauth,dc=com" \
  -w "AdminSecur1Auth2025!" \
  -b "dc=securiauth,dc=com"
```

### phpLDAPadmin (Interface Web)
- **URL** : http://localhost:8080
- **Login** : `cn=admin,dc=securiauth,dc=com`
- **Password** : `AdminSecur1Auth2025!`

### Services AAA
- **RADIUS 1** : localhost:1812 (auth), 1813 (accounting)
- **RADIUS 2** : localhost:1912 (auth), 1913 (accounting)
- **TACACS+ 1** : localhost:49
- **TACACS+ 2** : localhost:50
- **MySQL** : localhost:3306

---

## 📊 Vérification Post-Installation

```bash
# Vérifier conteneurs actifs
docker ps

# Test LDAP
ldapsearch -x -H ldap://localhost:389 \
  -D "cn=admin,dc=securiauth,dc=com" \
  -w "AdminSecur1Auth2025!" \
  -b "dc=securiauth,dc=com" "(uid=dieyna.diop)"

# Logs des services
docker compose logs -f

# Logs spécifique
docker logs securiauth-radius1
docker logs securiauth-tacacs1
```

---

## 🔐 Sécurité - IMPORTANT !

⚠️ **Avant déploiement en production, CHANGER tous les mots de passe par défaut :**

| Service | Utilisateur | Mot de passe par défaut | Commande pour changer |
|---------|-------------|-------------------------|----------------------|
| LDAP Admin | admin | `AdminSecur1Auth2025!` | `ldappasswd -x -H ldap://localhost:389 -D "cn=admin,dc=securiauth,dc=com" -w "AdminSecur1Auth2025!" -s "<NOUVEAU>" "cn=admin,dc=securiauth,dc=com"` |
| MySQL Root | root | `RootMySQL2025!` | Voir docs/GUIDE-COMPLET-FR.md |
| MySQL RADIUS | radiususer | `RadiusDB2025!` | Voir docs/GUIDE-COMPLET-FR.md |

**Clés à changer** :
- TACACS+ : `TacacsSecuriAuth2025!` dans `tacacs/config/tac_plus.conf`
- Secrets RADIUS dans `freeradius/config/clients.conf`
- Password certificats P12 : `SecuriAuth2025`

---

## 📚 Documentation

### Fichiers inclus

- **README.md** : Vue d'ensemble et démarrage rapide
- **README-PACKAGE.md** : Ce fichier
- **docs/GUIDE-COMPLET-FR.md** : Documentation exhaustive (661 lignes)
- **DEPLOYMENT-STATUS.md** : État du déploiement
- **RESUME-FINAL.txt** : Résumé complet

### Guides détaillés

Le fichier `docs/GUIDE-COMPLET-FR.md` contient :
- Architecture détaillée
- Configuration RADIUS/TACACS+
- Mapping VLANs et privilèges
- Procédures de tests
- Configuration switches Cisco/HP
- Dépannage
- Maintenance et sauvegardes

---

## 🛠️ Commandes Utiles

### Gestion des services

```bash
# Démarrer tous les services
docker compose up -d

# Arrêter tous les services
docker compose down

# Redémarrer un service
docker compose restart securiauth-radius1

# Voir les logs
docker compose logs -f

# État des services
docker ps
docker compose ps
```

### Sauvegarde

```bash
# Exporter LDAP
ldapsearch -x -H ldap://localhost:389 \
  -D "cn=admin,dc=securiauth,dc=com" \
  -w "AdminSecur1Auth2025!" \
  -b "dc=securiauth,dc=com" > backup-ldap.ldif

# Exporter MySQL
docker exec securiauth-mysql mysqldump \
  -uradiususer -pRadiusDB2025! radius > backup-radius.sql
```

### Nettoyage

```bash
# Script de nettoyage interactif
./scripts/cleanup.sh

# Ou manuellement
docker compose down -v  # Arrêter et supprimer volumes
```

---

## 🧪 Tests

### Test RADIUS (requiert freeradius-utils)

```bash
sudo apt-get install -y freeradius-utils

# Test simple PAP (adapter le mot de passe)
radtest dieyna.diop <PASSWORD> localhost:1812 0 testing123
```

### Test TACACS+ depuis switch Cisco

```cisco
! Configuration switch
tacacs-server host <IP_SERVEUR> key TacacsSecuriAuth2025!
aaa new-model
aaa authentication login default group tacacs+ local
aaa authorization exec default group tacacs+ local

! Test SSH
ssh dieyna.diop@<SWITCH_IP>
```

---

## 🐛 Dépannage

### Problème : Conteneur ne démarre pas

```bash
# Voir les logs
docker logs <nom_conteneur>

# Reconstruire l'image
docker compose build <service>
docker compose up -d <service>
```

### Problème : LDAP ne répond pas

```bash
# Vérifier que le conteneur tourne
docker ps | grep ldap

# Redémarrer LDAP
docker compose restart openldap

# Vérifier les logs
docker logs securiauth-ldap
```

### Problème : RADIUS rejette authentification

```bash
# Mode debug
docker exec -it securiauth-radius1 freeradius -X

# Vérifier connexion LDAP depuis RADIUS
docker exec securiauth-radius1 ldapsearch -x -H ldap://openldap:389 \
  -D "cn=admin,dc=securiauth,dc=com" \
  -w "AdminSecur1Auth2025!" \
  -b "dc=securiauth,dc=com"
```

---

## 📁 Structure du Package

```
securiauth-aaa/
├── INSTALL.sh                  # Script d'installation automatique ⭐
├── README.md                   # Vue d'ensemble
├── README-PACKAGE.md           # Ce fichier
├── DEPLOYMENT-STATUS.md
├── RESUME-FINAL.txt
├── docker-compose.yml          # Orchestration Docker
├── openldap/
│   └── ldif/                   # Données LDAP (utilisateurs, groupes)
├── freeradius/
│   ├── Dockerfile
│   ├── entrypoint.sh
│   └── config/                 # Configurations RADIUS
├── tacacs/
│   ├── Dockerfile
│   ├── entrypoint.sh
│   └── config/                 # Configuration TACACS+
├── pki/                        # Certificats (générés au premier démarrage)
├── scripts/
│   ├── generate-pki.sh         # Génération PKI
│   ├── cleanup.sh              # Nettoyage
│   └── test-infrastructure.sh  # Tests automatisés
└── docs/
    └── GUIDE-COMPLET-FR.md     # Documentation complète ⭐
```

---

## 🌍 Déploiement sur Autre Machine

### Option 1 : Copie du ZIP

```bash
# Sur la machine source (déjà créé par ce package)
# Transférer securiauth-aaa-v1.0.zip vers la nouvelle machine

# Sur la nouvelle machine
scp user@source:/chemin/securiauth-aaa-v1.0.zip .
unzip securiauth-aaa-v1.0.zip
cd securiauth-aaa
./INSTALL.sh
```

### Option 2 : Migration avec données

```bash
# Sur machine source
docker compose down
tar -czf securiauth-complete.tar.gz securiauth-aaa/

# Transférer vers nouvelle machine
scp securiauth-complete.tar.gz user@target:/home/user/

# Sur nouvelle machine
tar -xzf securiauth-complete.tar.gz
cd securiauth-aaa
docker compose up -d
```

---

## 📞 Support

### Contacts

- **Infrastructure** : Dieyna Diop - dieyna.diop@securiauth.com - +221 77 123 45 67
- **Support Technique** : Maman Seck - maman.seck@securiauth.com - +221 76 234 56 78
- **Helpdesk** : support@securiauth.com

### Ressources en ligne

- FreeRADIUS : https://freeradius.org/documentation/
- TACACS+ : http://www.shrubbery.net/tac_plus/
- OpenLDAP : https://www.openldap.org/doc/

---

## 📝 Notes de Version

**v1.0 (2025-11-05)**
- ✅ Déploiement initial complet
- ✅ OpenLDAP avec 6 utilisateurs sénégalais
- ✅ FreeRADIUS x2 (redondance)
- ✅ TACACS+ x2 (redondance)
- ✅ PKI complète
- ✅ Documentation exhaustive en français
- ✅ Script d'installation automatique

---

## ⚖️ Licence

© 2025 SecuriAuth Sénégal. Tous droits réservés.

---

**🇸🇳 SecuriAuth Sénégal - Infrastructure AAA 2025**

Pour toute question, consultez d'abord `docs/GUIDE-COMPLET-FR.md` !
