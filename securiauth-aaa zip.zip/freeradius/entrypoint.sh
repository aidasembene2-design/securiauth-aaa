#!/bin/bash
set -e

echo "=========================================="
echo "  FreeRADIUS - SecuriAuth Sénégal"
echo "  Serveur: $RADIUS_SERVER_NAME"
echo "=========================================="

# Attendre que LDAP soit prêt
echo "Attente de OpenLDAP..."
until nc -z $LDAP_SERVER 389; do
    sleep 2
done
echo "✓ OpenLDAP disponible"

# Attendre que MySQL soit prêt
echo "Attente de MySQL..."
until nc -z $MYSQL_HOST 3306; do
    sleep 2
done
echo "✓ MySQL disponible"

echo "Démarrage de FreeRADIUS..."
exec "$@"
