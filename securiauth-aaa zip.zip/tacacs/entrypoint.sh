#!/bin/bash
set -e

echo "=========================================="
echo "  TACACS+ - SecuriAuth Sénégal"
echo "  Serveur: $TACACS_SERVER_NAME"
echo "=========================================="

# Attendre que LDAP soit prêt
echo "Attente de OpenLDAP..."
until nc -z $LDAP_SERVER 389; do
    sleep 2
done
echo "✓ OpenLDAP disponible"

echo "Démarrage de TACACS+..."
exec "$@"
